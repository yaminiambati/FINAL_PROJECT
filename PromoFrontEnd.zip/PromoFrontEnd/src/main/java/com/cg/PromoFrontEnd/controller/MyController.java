package com.cg.PromoFrontEnd.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.client.RestTemplate;


import com.cg.PromoFrontEnd.model.Discount;


@Controller
public class MyController {
	
	@RequestMapping(value = "/" /*, method = RequestMethod.GET*/) 
	public String displayLogin(Model model,ModelMap map) { 
	    model.addAttribute("discount", new Discount()); 
		final String uri="http://localhost:8089/PromoRest/api/v2/discounts";
		RestTemplate restTemplate=new RestTemplate();
		
		Discount[] discounts= restTemplate.getForObject(uri, Discount[].class);
		if(discounts==null)
		{
			map.put("discounts",new Discount());
		}
		else {
			map.put("discounts",discounts);
		}
		
	    return "discountpromos";
	}
	/*@RequestMapping("/yamini")
	public String display() {
		
		//map.put("discounts", null);
	System.out.println("hello");
		return "discountpromos";
	}*/
	
/*	@RequestMapping("/discountpromos")
	public String Disp(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
				final String uri="http://localhost:8089/PromoRest/api/v2/discounts";
				RestTemplate restTemplate=new RestTemplate();
				
				Discount[] discounts= restTemplate.getForObject(uri, Discount[].class);
				
				map.put("discounts",discounts);
				map.put("discount", new Discount());
				
		return "discountpromos";
		
	}	*/
	
	/*@RequestMapping("/saveDiscount")
	public String showDiscountDetails(
			@ModelAttribute("discount") Discount discount,
			BindingResult result, ModelMap map) {
		if(!result.hasErrors()) 
			
			final String uri="http://localhost:8089/PromoRest/api/v2/discounts1";
			RestTemplate restTemplate=new RestTemplate();
			restTemplate.postForEntity(uri,discount,Discount.class);
				//	map.put("discounts",discounts);
					map.put("discount", new Discount());
		
				
		return "discountpromos";
	}*/
	@RequestMapping("/saveDiscount")
	public String showDiscountDetails(
			 @ModelAttribute("discount") Discount discount,ModelMap map) {
		
		 System.out.println(discount);	
		 
		
			final String uri="http://localhost:8089/PromoRest/api/v2/discounts";
			RestTemplate restTemplate=new RestTemplate();
			
		
			restTemplate.postForEntity(uri,discount,Discount.class);
			//restTemplate.put(uri,coupons,Coupons.class);
		
		
		map.put("discount",new Discount());

		return "discountpromos";
	}
	
}

