package com.capgemini.PromoRest.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.PromoRest.model.Discount;

@Repository("discountdao")
@Transactional
public interface DiscountDao extends JpaRepository<Discount,Integer> {

	

}
