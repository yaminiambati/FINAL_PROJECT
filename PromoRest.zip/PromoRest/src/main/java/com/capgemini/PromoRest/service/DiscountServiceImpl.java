package com.capgemini.PromoRest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.PromoRest.dao.DiscountDao;
import com.capgemini.PromoRest.model.Discount;

@Service("discountservice")
public class DiscountServiceImpl implements DiscountService {
	
	@Autowired
	private DiscountDao discountdao;

	@Override
	public List<Discount> getAll() {
		return discountdao.findAll();
	}

	@Override
	public void save(Discount discount) {
		// TODO Auto-generated method stub
		discountdao.save(discount);
	}

	@Override
	public void delete(Integer discountId) {
		// TODO Auto-generated method stub
		discountdao.deleteById(discountId);
	}

	@Override
	public Discount find(Integer discountId) {
		return discountdao.getOne(discountId);
	}

	
}
